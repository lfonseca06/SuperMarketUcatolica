package co.edu.ucatolica.modelo;

import java.io.Serializable;

public class Producto implements Serializable {
    private String codigo;
    private String nombre;
    private String NITProveedor;
    private double precioCompra;
    private double precioVenta;

    // Getters y Setters
}

