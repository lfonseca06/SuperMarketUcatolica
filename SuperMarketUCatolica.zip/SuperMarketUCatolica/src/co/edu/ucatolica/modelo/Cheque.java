package co.edu.ucatolica.modelo;

import java.io.Serializable;

public class Cheque implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String consecutivo;
    private String codigoCompra;
    private String NITProveedor;
    private double valorTotal;

    // Getters y Setters
}
