package co.edu.ucatolica.modelo;

import java.io.Serializable;

public class Proveedor implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String NIT;
    private String nombre;
    private String direccion;
    private String telefono;
    private String ciudad;

    // Getters y Setters
}
