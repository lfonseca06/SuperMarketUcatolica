package co.edu.ucatolica.modelo;

import java.io.Serializable;

public class DetalleCompra implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String codigoProducto;
    private int cantidad;
    private double valorUnitario;
    private double valorTotal;

    // Getters y Setters
}
